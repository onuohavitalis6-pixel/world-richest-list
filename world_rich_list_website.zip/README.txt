WORLD RICH LIST 2026
====================

Files:
- index.html — main website
- top-20-richest-people-world-2026.pdf — downloadable report

To publish:
1. Upload these files to a static website host.
2. Make sure index.html is the homepage.
3. Keep the PDF in the same folder.
4. After publishing, submit the site URL in Google Search Console.

Important:
The ranking is a snapshot and should be checked against current authoritative billionaire data before treating it as a live ranking.
